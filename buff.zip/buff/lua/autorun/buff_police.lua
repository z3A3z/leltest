list.Set( "PlayerOptionsModel",  "Buff Police", "models/kyzooxoo/player/buff_police.mdl" )
player_manager.AddValidModel( "Buff Police", "models/kyzooxoo/player/buff_police.mdl" );